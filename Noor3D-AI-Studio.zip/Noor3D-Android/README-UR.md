# Noor3D AI Studio — Android + AI Backend

یہ ایک قابلِ توسیع Android پروجیکٹ ہے جس میں بنیادی OpenGL 3D preview/offline MP4 renderer کے ساتھ اختیاری cloud AI integration بھی شامل ہے۔ اسے جان بوجھ کر دو حصوں میں رکھا گیا ہے: Android app اور محفوظ server-side AI backend۔

## اس ZIP میں کیا شامل ہے؟

- Android Studio project (Kotlin، OpenGL ES 2.0، min SDK 26)
- Portrait UI، Urdu/English prompt input، scene selector، device TTS voice preview، بنیادی offline animation preview
- مقامی renderer سے 720p MP4 export کی کوشش
- AI Cloud Studio: backend کے ذریعے حقیقی text-to-video generation کی درخواست، واپس آنے والی MP4 کو `Movies/Noor3D` میں محفوظ کرنا
- AI Cloud Studio: Meshy کے ذریعے text-to-3D generation اور GLB فائل ڈاؤن لوڈ
- `backend/` میں Node.js API، Dockerfile، `.env.example` اور اردو deployment guide
- GitHub Actions workflow جو Android debug APK build کرے

## پہلے یہ حقیقت جان لیں

**یہ ابھی مکمل خودکار 2 منٹ کی فلم بنانے والا سسٹم نہیں ہے۔** Cloud video button فی درخواست 5 یا 10 سیکنڈ کا 720p کلپ بناتا ہے۔ دو منٹ کی فلم کے لیے متعدد کلپس، ایک جیسے کردار کی consistency، shot planning، audio/lip-sync، clips کی stitching اور final render کی مزید engineering درکار ہے۔ Meshy سے بننے والا GLB فی الحال فون کے app-specific Downloads فولڈر میں محفوظ ہوتا ہے؛ ایپ میں GLB viewer، auto-rigging اور character animation ابھی شامل نہیں۔

Cloud features اس وقت تک کام نہیں کریں گے جب تک backend کو deploy کرکے درست provider API keys نہ لگائی جائیں۔ یہ API keys اور credits ZIP میں شامل نہیں ہیں۔ Build کامیاب ہونا بھی حقیقی AI API یا فون پر playback کی کامیابی کی ضمانت نہیں ہے۔

## Cloud AI سیٹ اپ (ایک مرتبہ)

1. `backend/README-UR.md` پڑھیں۔
2. ایک HTTPS backend host پر `backend` deploy کریں (Dockerfile موجود ہے)۔
3. host کے environment variables میں `FAL_KEY`، `MESHY_API_KEY` اور ایک لمبا random `APP_API_TOKEN` رکھیں۔ provider keys کو GitHub source، ZIP یا APK میں نہ لکھیں۔
4. `https://YOUR-ACTUAL-DOMAIN/health` کھولیں؛ `ok: true` آنا چاہیے۔ `providers` true صرف key موجود ہونے کا اشارہ ہے، credits یا کامیاب generation کی ضمانت نہیں۔
5. APK کھول کر **AI Cloud Studio** کے URL خانے میں اپنی حقیقی HTTPS backend URL اور اگلے خانے میں server کا وہی `APP_API_TOKEN` لکھیں۔ مثال کا domain استعمال نہ کریں۔
6. prompt لکھ کر **Generate AI video** یا **Generate AI 3D model** دبائیں۔ Video `Movies/Noor3D` میں اور GLB app-specific Download storage میں محفوظ ہوتا ہے۔

## API providers / لاگت

- Video: fal.ai `fal-ai/wan-25-preview/text-to-video`، 16:9، 720p، 5 یا 10 سیکنڈ فی درخواست۔
- 3D model: Meshy Text-to-3D preview + refine، GLB output۔
- ان سروسز کے لیے اکاؤنٹ، API access اور credits/ادائیگی درکار ہو سکتی ہے۔ مفت یا لامحدود generation کی ضمانت نہیں۔ ہر generation سے پہلے موجودہ قیمت اور terms دیکھیں۔
- موجودہ starter backend میں user authentication/rate limiting ابھی شامل نہیں؛ اسے عوامی production service بنانے سے پہلے ضرور لگائیں، ورنہ دوسرا شخص آپ کے credits خرچ کر سکتا ہے۔

## GitHub سے APK بنانا (Android فون سے)

### اگر ZIP کے اندر کی تمام فائلیں repository میں ڈال سکتے ہیں

1. ZIP extract کریں اور `Noor3D-Android` فولڈر کے اندر کی فائلیں repository کے root میں upload/commit کریں۔ صرف ZIP فائل upload کرنے سے اندر کا workflow خود build نہیں کرے گا۔
2. `Actions` کھولیں، `Build Noor3D Android APK` منتخب کریں اور `Run workflow` دبائیں۔
3. کامیابی کے بعد run کے نیچے `Artifacts` سے `Noor3D-debug-apk` ڈاؤن لوڈ کریں۔

### اگر repository میں صرف ZIP فائل upload کرنی ہے

ZIP کے باہر دی گئی `Noor3D-zip-build.yml` فائل کو repository میں `.github/workflows/build.yml` کے نام سے رکھیں، پھر ZIP کو repository root میں `Noor3D-AI-Studio.zip` نام دیں۔ workflow ZIP کو extract کرکے Android project build کرنے کی کوشش کرے گا۔

## Build details

- JDK 17; Gradle 8.9; Android Gradle Plugin 8.6.1; Kotlin 2.0.20
- compile/target SDK 35; min SDK 26
- Vivo Y36 پر حقیقی device test ابھی نہیں کیا گیا۔ اس source ZIP کی integrity اور source structure دیکھی گئی ہے، لیکن اس ماحول میں Android SDK build نہیں چلایا گیا؛ GitHub Actions کا نتیجہ اصل build verification ہوگا۔
