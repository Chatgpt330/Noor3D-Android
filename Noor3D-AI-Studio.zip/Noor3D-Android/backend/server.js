import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import { fal } from '@fal-ai/client';

const app = express();
app.disable('x-powered-by');
app.use(helmet());
app.use(cors({ origin: true }));
app.use(express.json({ limit: '256kb' }));
// Set APP_API_TOKEN in hosting and enter the same token in the Android app to protect paid endpoints.
app.use(['/api/video', '/api/model'], (req, res, next) => {
  const expected = process.env.APP_API_TOKEN;
  if (!expected) return next(); // Useful for private testing only; configure a token before public use.
  const supplied = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (supplied !== expected) return res.status(401).json({ error: 'Backend access token is missing or incorrect.' });
  next();
});
const PORT = Number(process.env.PORT || 8080);

app.get('/health', (_req, res) => res.json({ ok: true, service: 'Noor3D AI Backend', providers: { video: Boolean(process.env.FAL_KEY), model3d: Boolean(process.env.MESHY_API_KEY) } }));

function requiredText(value, label, max = 1500) {
  if (typeof value !== 'string' || !value.trim()) throw new Error(`${label} is required`);
  const text = value.trim();
  if (text.length > max) throw new Error(`${label} must be ${max} characters or fewer`);
  return text;
}

app.post('/api/video', async (req, res) => {
  try {
    if (!process.env.FAL_KEY) return res.status(503).json({ error: 'Video service is not configured. Set FAL_KEY on the backend host.' });
    const prompt = requiredText(req.body?.prompt, 'prompt', 1500);
    const requestedDuration = Number(req.body?.duration || 5);
    const duration = requestedDuration > 5 ? 10 : 5;
    fal.config({ credentials: process.env.FAL_KEY });
    // WAN 2.5 generates a short cinematic clip. It does not create a complete 2-minute film in one request.
    const result = await fal.subscribe('fal-ai/wan-25-preview/text-to-video', {
      input: {
        prompt,
        aspect_ratio: '16:9',
        resolution: '720p',
        duration,
        enable_safety_checker: true
      },
      logs: false
    });
    const videoUrl = result?.data?.video?.url || result?.data?.video_url || result?.data?.url;
    if (!videoUrl) return res.status(502).json({ error: 'Provider completed without returning a recognized video URL.' });
    return res.json({ videoUrl, duration, resolution: '720p', aspectRatio: '16:9', requestId: result.requestId || null, provider: 'fal.ai / WAN 2.5' });
  } catch (error) {
    console.error('video generation error:', error?.message || error);
    const status = /required|characters or fewer/.test(error?.message || '') ? 400 : 502;
    return res.status(status).json({ error: error?.message || 'Video generation failed. Check provider quota and backend logs.' });
  }
});

async function meshyRequest(path, options = {}) {
  const response = await fetch(`https://api.meshy.ai${path}`, {
    ...options,
    headers: { Authorization: `Bearer ${process.env.MESHY_API_KEY}`, 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const raw = await response.text();
  let data;
  try { data = raw ? JSON.parse(raw) : {}; } catch { data = { message: raw.slice(0, 500) }; }
  if (!response.ok) throw new Error(`Meshy HTTP ${response.status}: ${data.message || data.error || raw.slice(0, 250)}`);
  return data;
}

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
async function waitForMeshyTask(taskId, timeoutMs = 9 * 60 * 1000) {
  const started = Date.now();
  while (Date.now() - started < timeoutMs) {
    const task = await meshyRequest(`/openapi/v2/text-to-3d/${encodeURIComponent(taskId)}`, { method: 'GET', headers: { 'Content-Type': 'application/json' } });
    const status = String(task.status || '').toUpperCase();
    if (status === 'SUCCEEDED') return task;
    if (['FAILED', 'CANCELED', 'EXPIRED'].includes(status)) throw new Error(`Meshy task ${status}: ${task.task_error?.message || task.message || 'No additional detail'}`);
    await sleep(5000);
  }
  throw new Error('Meshy generation timed out. Check your Meshy task history before retrying to avoid duplicate charges.');
}

app.post('/api/model', async (req, res) => {
  try {
    if (!process.env.MESHY_API_KEY) return res.status(503).json({ error: '3D model service is not configured. Set MESHY_API_KEY on the backend host.' });
    const prompt = requiredText(req.body?.prompt, 'prompt', 800);
    const preview = await meshyRequest('/openapi/v2/text-to-3d', {
      method: 'POST', body: JSON.stringify({
        mode: 'preview', prompt,
        ai_model: 'meshy-7.1',
        geometry_resolution: '2k',
        should_remesh: true,
        target_polycount: 50000,
        pose_mode: 'a-pose',
        target_formats: ['glb']
      })
    });
    const previewId = preview.result || preview.id;
    if (!previewId) throw new Error('Meshy preview task did not return a task ID.');
    const previewResult = await waitForMeshyTask(previewId);
    const refine = await meshyRequest('/openapi/v2/text-to-3d', {
      method: 'POST', body: JSON.stringify({ mode: 'refine', preview_task_id: previewId, ai_model: 'meshy-7.1', enable_pbr: true, target_formats: ['glb'], auto_size: true })
    });
    const refineId = refine.result || refine.id;
    if (!refineId) throw new Error('Meshy refine task did not return a task ID.');
    const finalTask = await waitForMeshyTask(refineId);
    const modelUrl = finalTask.model_urls?.glb || finalTask.model_urls?.['glb'] || finalTask.result?.model_urls?.glb;
    if (!modelUrl) throw new Error('Meshy finished but did not provide a GLB URL.');
    return res.json({ modelUrl, format: 'glb', previewTaskId: previewId, refineTaskId: refineId, provider: 'Meshy text-to-3D' });
  } catch (error) {
    console.error('3D model generation error:', error?.message || error);
    const status = /required|characters or fewer/.test(error?.message || '') ? 400 : 502;
    return res.status(status).json({ error: error?.message || '3D generation failed. Check Meshy quota and backend logs.' });
  }
});

app.listen(PORT, '0.0.0.0', () => console.log(`Noor3D AI backend listening on ${PORT}`));
