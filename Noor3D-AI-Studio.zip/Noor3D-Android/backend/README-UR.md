# Noor3D AI Backend (اردو)

یہ سرور Android app کو حقیقی بیرونی AI generation APIs سے جوڑتا ہے:

- **Text-to-video:** fal.ai کا WAN 2.5، 16:9 اور 720p، فی درخواست 5 یا 10 سیکنڈ کا کلپ۔
- **Text-to-3D:** Meshy Text-to-3D preview → textured/refined GLB۔
- **API keys صرف سرور پر رہتی ہیں**؛ APK یا GitHub میں حقیقی key ہرگز نہ رکھیں۔

## ضروری چیزیں

1. Node.js 22+ یا Docker hosting جس پر HTTPS دستیاب ہو۔
2. fal.ai account اور API key؛ generation عموماً credits/ادائیگی استعمال کر سکتی ہے۔
3. Meshy Developer account اور API key؛ API key بنانے اور Text-to-3D استعمال کرنے کے لیے مناسب paid plan/credits درکار ہو سکتے ہیں۔
4. Hosting provider میں environment variables `FAL_KEY` اور `MESHY_API_KEY` لگائیں۔ `PORT` hosting خود دیتی ہے تو اسے نہ بدلیں۔

## Deploy (آسان طریقہ: Render / Railway / کسی Docker host پر)

- Repository root میں `backend` فولڈر موجود ہے۔ Host کو `backend` بطور Root Directory دیں، یا Dockerfile کے طور پر `backend/Dockerfile` منتخب کریں۔
- Start command: `npm start` (Docker استعمال کریں تو پہلے سے مقرر ہے)۔
- Environment variables میں `FAL_KEY` اور `MESHY_API_KEY` محفوظ طور پر درج کریں۔
- Deploy ہونے کے بعد `https://YOUR-DOMAIN/health` کھولیں۔ `ok: true` آنا چاہیے۔ `providers` میں true کا مطلب صرف key موجود ہے، یہ credits یا API کی کامیابی کی ضمانت نہیں۔
- Android app کے **AI Cloud Studio** والے URL خانے میں صرف deployed HTTPS domain لکھیں، مثلاً `https://noor3d-api.example.com`۔ مثال والا domain استعمال نہ کریں؛ اسے اپنے host کے اصل domain سے بدلیں۔ نیچے token والے خانے میں وہی `APP_API_TOKEN` درج کریں جو hosting میں محفوظ کیا ہے۔

## API endpoints

`POST /api/video`

```json
{"prompt":"A cinematic fantasy hero walks through a rainy neon city","duration":10,"aspectRatio":"16:9","resolution":"720p"}
```

جواب میں `videoUrl` آئے گا؛ ایپ اسے فون کے `Movies/Noor3D` فولڈر میں محفوظ کرتی ہے۔ WAN 2.5 کی ایک درخواست 5 یا 10 سیکنڈ بناتی ہے؛ 2 منٹ کی فلم کے لیے متعدد کلپس، consistency/shot planning اور stitching درکار ہیں، جو اس ابتدائی backend میں مکمل نہیں۔

`POST /api/model`

```json
{"prompt":"A stylized heroic fantasy knight, full body, detailed armor, A-pose"}
```

جواب میں `modelUrl` (GLB) آتا ہے۔ موجودہ Android UI اسے app-specific Downloads فولڈر میں محفوظ کرتی ہے؛ GLB کو ایپ کے 3D preview میں دکھانا یا skeleton rig/animation خودکار طور پر لگانا ابھی شامل نہیں۔

## اہم سکیورٹی اور لاگت

- حقیقی API keys کبھی ZIP، source code، APK یا public GitHub commit میں نہ رکھیں۔
- `APP_API_TOKEN` لگا کر backend endpoints کو محدود کریں۔ یہ سادہ shared-token protection ہے، مکمل user accounts، rate limits یا per-user quotas نہیں؛ بڑی public service کے لیے مزید controls درکار ہیں۔
- AI output، معیار، وقت، قیمت، availability اور provider limits بیرونی سروس پر منحصر ہیں؛ مفت یا لامحدود generation کی ضمانت نہیں۔
- ہر generation سے پہلے provider کی تازہ قیمت اور terms دیکھیں۔ Failed/timeout task کے بعد دوبارہ چلانے سے پہلے provider dashboard میں task status دیکھیں تاکہ دوہرا خرچ نہ ہو۔
