package com.noor3d.studio

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.content.ContentValues
import android.net.Uri
import android.os.Environment
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import android.os.Build
import android.provider.MediaStore
import android.widget.*
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var scene: AnimationSurface
    private lateinit var prompt: EditText
    private lateinit var story: TextView
    private lateinit var status: TextView
    private lateinit var generateButton: Button
    private lateinit var exportButton: Button
    private lateinit var aiServerUrl: EditText
    private lateinit var aiServerToken: EditText
    private lateinit var aiVideoButton: Button
    private lateinit var aiModelButton: Button
    private lateinit var durationLabel: TextView
    private lateinit var voiceSpinner: Spinner
    private lateinit var sceneSpinner: Spinner
    private lateinit var languageButton: Button
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var urdu = true
    private var playing = true
    private var durationSeconds = 30
    private var selectedScene = 0
    private var selectedVoice = 0
    private val exporting = AtomicBoolean(false)
    private var lastGeneratedStory = "A character walks through a peaceful green garden, waves, and looks at the camera."

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        window.statusBarColor = Color.rgb(11, 16, 30)
        window.navigationBarColor = Color.rgb(11, 16, 30)
        window.decorView.systemUiVisibility = 0
        tts = TextToSpeech(this, this)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(11, 16, 30))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(14), dp(12))
            setBackgroundColor(Color.rgb(18, 27, 47))
        }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(TextView(this).apply {
            text = "NOOR3D STUDIO"
            textSize = 19f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        brand.addView(TextView(this).apply {
            text = if (urdu) "تھری ڈی اینیمیشن ورک اسپیس" else "3D ANIMATION WORKSPACE"
            textSize = 11f
            setTextColor(Color.rgb(155, 174, 210))
        })
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        languageButton = button("اردو / English") { urdu = !urdu; updateLanguage() }
        header.addView(languageButton)
        root.addView(header)

        val scroll = ScrollView(this).apply { fillViewport = true; clipToPadding = false }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(24))
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(sectionTitle("3D منظر / 3D Preview"))
        scene = AnimationSurface(this)
        scene.setBackgroundColor(Color.rgb(70, 128, 174))
        content.addView(scene, LinearLayout.LayoutParams(-1, dp(245)).apply { bottomMargin = dp(10) })

        val playback = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 0, 0, dp(10)) }
        val play = button(if (urdu) "⏸ روکیں" else "⏸ Pause") {
            playing = !playing
            scene.setPlaying(playing)
            (it as Button).text = if (playing) { if (urdu) "⏸ روکیں" else "⏸ Pause" } else { if (urdu) "▶ چلائیں" else "▶ Play" }
        }
        val reset = button(if (urdu) "↻ دوبارہ" else "↻ Reset") { scene.resetAnimation(); playing = true }
        playback.addView(play, LinearLayout.LayoutParams(0, dp(46), 1f).apply { rightMargin = dp(6) })
        playback.addView(reset, LinearLayout.LayoutParams(0, dp(46), 1f).apply { leftMargin = dp(6) })
        content.addView(playback)

        content.addView(sectionTitle("اپنی کہانی یا پرامپٹ لکھیں / Write your story or prompt"))
        prompt = EditText(this).apply {
            setText(if (urdu) "ایک کردار خوبصورت باغ میں چلتا ہے، ہاتھ ہلاتا ہے اور کیمرے کی طرف دیکھتا ہے۔" else "A character walks through a beautiful garden, waves, and looks at the camera.")
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            hint = if (urdu) "مثلاً: ایک ہیرو شہر میں داخل ہوتا ہے..." else "Example: A hero enters a futuristic city..."
            textSize = 15f
            gravity = Gravity.TOP or Gravity.START
            minLines = 3
            maxLines = 6
            setPadding(dp(13), dp(12), dp(13), dp(12))
            setBackgroundColor(Color.rgb(26, 37, 59))
        }
        content.addView(prompt, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        content.addView(sectionTitle("منظر اور آواز / Scene and voice"))
        sceneSpinner = spinner(listOf("Garden / باغ", "City / شہر", "Space / خلا", "Studio / اسٹوڈیو"))
        content.addView(sceneSpinner, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        sceneSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedScene = position
                scene.setScene(position)
            }
        }
        voiceSpinner = spinner(listOf("Male voice / مردانہ آواز", "Female voice / زنانہ آواز"))
        content.addView(voiceSpinner, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        voiceSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { selectedVoice = position }
        }

        durationLabel = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; text = durationText() }
        content.addView(durationLabel)
        val durationSeek = SeekBar(this).apply { max = 118; progress = 28; progressTintList = android.content.res.ColorStateList.valueOf(Color.rgb(102, 125, 255)); thumbTintList = android.content.res.ColorStateList.valueOf(Color.rgb(154, 167, 255)) }
        content.addView(durationSeek)
        durationSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { durationSeconds = progress + 2; durationLabel.text = durationText() }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        generateButton = button(if (urdu) "✦ کہانی سے اینیمیشن تیار کریں" else "✦ Build animation from prompt") { generateStory() }
        content.addView(generateButton, LinearLayout.LayoutParams(-1, dp(50)).apply { topMargin = dp(8); bottomMargin = dp(8) })
        val speakButton = button(if (urdu) "🔊 آواز سنیں" else "🔊 Preview voice") { speakStory() }
        content.addView(speakButton, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(8) })

        story = TextView(this).apply {
            text = if (urdu) "آپ کی کہانی یہاں منظر کے خلاصے میں نظر آئے گی۔" else "Your scene plan will appear here."
            textSize = 13f
            setTextColor(Color.rgb(203, 215, 237))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(20, 30, 49))
        }
        content.addView(story, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })

        exportButton = button(if (urdu) "⬇ 720p MP4 ویڈیو بنائیں" else "⬇ Export 720p MP4 video") { exportVideo() }
        content.addView(exportButton, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(8) })

        content.addView(sectionTitle("AI Cloud Studio / AI کلاؤڈ اسٹوڈیو"))
        aiServerUrl = EditText(this).apply {
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); textSize = 13f
            hint = "https://your-deployed-noor3d-api.example.com"
            setSingleLine(true); setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(26, 37, 59))
        }
        content.addView(aiServerUrl, LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) })
        aiServerToken = EditText(this).apply {
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); textSize = 13f
            hint = "Optional backend access token (if configured on server)"
            setSingleLine(true); inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            setPadding(dp(12), dp(10), dp(12), dp(10)); setBackgroundColor(Color.rgb(26, 37, 59))
        }
        content.addView(aiServerToken, LinearLayout.LayoutParams(-1, dp(46)).apply { bottomMargin = dp(8) })
        aiVideoButton = button("✨ Generate AI video (5–10 sec)") { generateCloudVideo() }
        content.addView(aiVideoButton, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(7) })
        aiModelButton = button("🧍 Generate AI 3D model (GLB)") { generateCloudModel() }
        content.addView(aiModelButton, LinearLayout.LayoutParams(-1, dp(50)).apply { bottomMargin = dp(8) })
        content.addView(TextView(this).apply {
            text = "AI cloud buttons require a deployed backend and paid/authorized provider API keys. Keys stay on the server, not inside this APK. AI video currently creates a short 5–10 second clip; it does not magically produce a finished 2-minute film."
            textSize = 11f; setTextColor(Color.rgb(173, 190, 218)); setPadding(dp(4), dp(4), dp(4), dp(10))
        })
        status = TextView(this).apply {
            text = if (urdu) "تیار — پرامپٹ لکھیں اور اینیمیشن تیار کریں۔" else "Ready — enter a prompt and build an animation."
            textSize = 12f
            setTextColor(Color.rgb(156, 181, 214))
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(6), dp(4), dp(6))
        }
        content.addView(status)
        content.addView(TextView(this).apply {
            text = if (urdu) "نوٹ: اس ورژن میں 3D پیش منظر، آف لائن سین پلانر، ڈیوائس کی TTS آواز اور MP4 رینڈرنگ شامل ہیں۔ مکمل AI سے نئے 3D ماڈلز بنانے کے لیے الگ AI سروس اور اس کی رسائی درکار ہے۔" else "Note: This build includes a 3D preview, offline scene planner, device TTS voice, and MP4 rendering. Generating brand-new 3D assets with AI requires a configured AI service and access credentials."
            textSize = 11f
            setTextColor(Color.rgb(132, 149, 178))
            setPadding(dp(4), dp(10), dp(4), 0)
        })
        setContentView(root)
    }

    private fun generateStory() {
        val raw = prompt.text.toString().trim()
        if (raw.isBlank()) { prompt.error = if (urdu) "کہانی لکھیں" else "Please enter a prompt"; return }
        lastGeneratedStory = buildScenePlan(raw, selectedScene, durationSeconds, urdu)
        scene.setScene(selectedScene)
        scene.setPrompt(raw)
        scene.resetAnimation()
        playing = true
        story.text = lastGeneratedStory
        status.text = if (urdu) "منظر تیار ہے۔ یہ آف لائن بنیادی سین پلان ہے، AI ماڈل جنریشن نہیں۔" else "Scene plan ready. This is an offline scene plan, not AI model generation."
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(prompt.windowToken, 0)
    }

    private fun buildScenePlan(raw: String, sceneId: Int, seconds: Int, isUrdu: Boolean): String {
        val sceneName = listOf("Garden / باغ", "City / شہر", "Space / خلا", "Studio / اسٹوڈیو")[sceneId]
        val actions = mutableListOf<String>()
        val lower = raw.lowercase(Locale.ROOT)
        if (lower.contains("walk") || raw.contains("چل")) actions.add(if (isUrdu) "کردار چلنے کی حرکت کرے گا" else "Character walking cycle")
        if (lower.contains("wave") || raw.contains("ہاتھ ہلا")) actions.add(if (isUrdu) "کردار ہاتھ ہلائے گا" else "Character wave gesture")
        if (lower.contains("jump") || raw.contains("چھلانگ")) actions.add(if (isUrdu) "کردار چھلانگ لگائے گا" else "Character jump")
        if (lower.contains("run") || raw.contains("دوڑ")) actions.add(if (isUrdu) "کردار دوڑے گا" else "Character running cycle")
        if (actions.isEmpty()) actions.add(if (isUrdu) "کردار کی مسلسل بنیادی حرکت اور کیمرہ منظر" else "Character idle motion and camera scene")
        val durationLine = if (isUrdu) "دورانیہ: $seconds سیکنڈ" else "Duration: $seconds seconds"
        return if (isUrdu) "منظر: $sceneName\nکہانی: $raw\nحرکت: ${actions.joinToString("، ")}\n$durationLine\nویڈیو فارمیٹ: 1280 × 720، MP4"
        else "Scene: $sceneName\nStory: $raw\nAnimation: ${actions.joinToString(", ")}\n$durationLine\nVideo format: 1280 × 720, MP4"
    }

    private fun configureTtsVoice(): Boolean {
        val engine = tts ?: return false
        val desiredLocale = if (urdu) Locale("ur") else Locale.US
        val languageResult = engine.setLanguage(desiredLocale)
        val languageAvailable = languageResult != TextToSpeech.LANG_MISSING_DATA && languageResult != TextToSpeech.LANG_NOT_SUPPORTED
        if (!languageAvailable) engine.setLanguage(Locale.US)
        val languageCode = if (languageAvailable) desiredLocale.language else "en"
        val candidates = engine.voices?.filter { it.locale.language == languageCode } ?: emptyList()
        val chosen = if (selectedVoice == 1) {
            candidates.firstOrNull { val n = it.name.lowercase(Locale.ROOT); n.contains("female") || n.contains("woman") }
        } else {
            candidates.firstOrNull { val n = it.name.lowercase(Locale.ROOT); n.contains("male") && !n.contains("female") }
        } ?: candidates.firstOrNull()
        if (chosen != null) engine.voice = chosen
        return languageAvailable && chosen != null && (if (selectedVoice == 1) chosen.name.lowercase(Locale.ROOT).let { it.contains("female") || it.contains("woman") } else chosen.name.lowercase(Locale.ROOT).contains("male") && !chosen.name.lowercase(Locale.ROOT).contains("female"))
    }

    private fun speakStory() {
        if (!ttsReady) { status.text = if (urdu) "آواز کی سروس تیار ہو رہی ہے؛ چند لمحے بعد کوشش کریں۔" else "Text-to-speech is still starting. Try again shortly."; return }
        val text = prompt.text.toString().trim().ifBlank { lastGeneratedStory }
        val genderVoiceAvailable = configureTtsVoice()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "noor3d-story")
        status.text = if (genderVoiceAvailable) {
            if (urdu) "فون کی دستیاب منتخب آواز میں کہانی سنائی جا رہی ہے۔" else "Speaking with the selected device voice."
        } else {
            if (urdu) "کہانی سنائی جا رہی ہے؛ منتخب جنس/زبان کی مخصوص آواز فون میں نہ ہو تو ڈیفالٹ آواز استعمال ہوگی۔" else "Speaking; if the selected language/gender voice is not installed, the device default voice is used."
        }
    }

    private fun exportVideo() {
        if (!exporting.compareAndSet(false, true)) return
        exportButton.isEnabled = false
        generateButton.isEnabled = false
        status.text = if (urdu) "3D MP4 رینڈرنگ شروع ہو رہی ہے…" else "Starting 3D MP4 rendering…"
        val rawPrompt = prompt.text.toString().trim().ifBlank { lastGeneratedStory }
        val secs = durationSeconds
        val sceneId = selectedScene
        val narrationAvailable = ttsReady && tts != null
        val genderVoiceAvailable = if (narrationAvailable) configureTtsVoice() else false
        Thread {
            val stamp = System.currentTimeMillis()
            val videoOnly = File(cacheDir, "noor3d_${stamp}_video.mp4")
            val wavFile = File(cacheDir, "noor3d_${stamp}_voice.wav")
            val audioOnly = File(cacheDir, "noor3d_${stamp}_audio.mp4")
            val finalVideo = File(cacheDir, "noor3d_${stamp}_final.mp4")
            try {
                Mp4AnimationExporter(this).export(videoOnly, secs, sceneId, rawPrompt) { done, total ->
                    runOnUiThread {
                        status.text = if (urdu) "3D ویڈیو رینڈر ہو رہی ہے: $done / $total فریم" else "Rendering 3D video: $done / $total frames"
                    }
                }
                var fileToSave = videoOnly
                var narrationAdded = false
                if (narrationAvailable) {
                    try {
                        runOnUiThread { status.text = if (urdu) "آواز تیار اور ویڈیو کے ساتھ شامل ہو رہی ہے…" else "Generating narration and adding it to the video…" }
                        NarrationMuxer().synthesizeAndMux(tts!!, rawPrompt, wavFile, videoOnly, audioOnly, finalVideo, secs)
                        fileToSave = finalVideo
                        narrationAdded = true
                    } catch (audioError: Exception) {
                        runOnUiThread { status.text = (if (urdu) "آواز شامل نہ ہو سکی؛ خاموش ویڈیو محفوظ کی جا رہی ہے: " else "Narration could not be embedded; saving the video without audio: ") + (audioError.message ?: audioError.javaClass.simpleName) }
                    }
                }
                val uri = saveToMovies(fileToSave)
                val finalNarrationAdded = narrationAdded
                runOnUiThread {
                    status.text = if (finalNarrationAdded) {
                        if (urdu) "720p MP4 آواز سمیت محفوظ ہوگئی: Movies/Noor3D\n$uri" else "720p MP4 with narration saved to Movies/Noor3D\n$uri"
                    } else {
                        if (urdu) "720p MP4 محفوظ ہوگئی (آواز شامل نہیں ہوئی): Movies/Noor3D\n$uri" else "720p MP4 saved without narration: Movies/Noor3D\n$uri"
                    }
                    if (!genderVoiceAvailable && finalNarrationAdded) status.append(if (urdu) "\nنوٹ: فون کی ڈیفالٹ TTS آواز استعمال ہوئی۔" else "\nNote: the phone's default TTS voice was used.")
                    Toast.makeText(this, if (urdu) "MP4 ویڈیو محفوظ ہوگئی" else "MP4 video saved", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                runOnUiThread { status.text = (if (urdu) "ایکسپورٹ ناکام: " else "Export failed: ") + (e.message ?: e.javaClass.simpleName) }
            } finally {
                videoOnly.delete(); wavFile.delete(); audioOnly.delete(); finalVideo.delete()
                runOnUiThread { exportButton.isEnabled = true; generateButton.isEnabled = true; exporting.set(false) }
            }
        }.start()
    }

    private fun normalizedApiBase(): String {
        val raw = aiServerUrl.text.toString().trim().trimEnd('/')
        if (raw.isBlank() || !raw.startsWith("https://")) throw IllegalArgumentException("Enter the HTTPS URL of your deployed Noor3D backend first.")
        return raw
    }

    private fun generateCloudVideo() {
        val rawPrompt = prompt.text.toString().trim()
        if (rawPrompt.isBlank()) { prompt.error = "Write a scene prompt first"; return }
        val base = try { normalizedApiBase() } catch (e: Exception) { status.text = e.message; return }
        aiVideoButton.isEnabled = false; aiModelButton.isEnabled = false
        status.text = "Submitting prompt to AI video service…"
        Thread {
            try {
                val body = JSONObject().put("prompt", rawPrompt).put("duration", if (durationSeconds <= 5) 5 else 10).put("aspectRatio", "16:9").put("resolution", "720p")
                val response = postJson("$base/api/video", body)
                val videoUrl = response.optString("videoUrl", "")
                if (!videoUrl.startsWith("https://")) throw IllegalStateException(response.optString("error", "AI service did not return a video URL"))
                runOnUiThread { status.text = "AI video generated. Downloading to Movies/Noor3D…" }
                val temp = File(cacheDir, "ai_${System.currentTimeMillis()}.mp4")
                URL(videoUrl).openStream().use { input -> temp.outputStream().use { output -> input.copyTo(output) } }
                val saved = saveToMovies(temp); temp.delete()
                runOnUiThread { status.text = "AI video saved in Movies/Noor3D. This is the provider-generated short clip, not the offline renderer." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "AI video failed: ${e.message ?: "network/provider error"}" }
            } finally { runOnUiThread { aiVideoButton.isEnabled = true; aiModelButton.isEnabled = true } }
        }.start()
    }

    private fun generateCloudModel() {
        val rawPrompt = prompt.text.toString().trim()
        if (rawPrompt.isBlank()) { prompt.error = "Describe the 3D character/object first"; return }
        val base = try { normalizedApiBase() } catch (e: Exception) { status.text = e.message; return }
        aiVideoButton.isEnabled = false; aiModelButton.isEnabled = false
        status.text = "Generating and texturing a 3D model in the cloud. This may take several minutes…"
        Thread {
            try {
                val body = JSONObject().put("prompt", rawPrompt)
                val response = postJson("$base/api/model", body)
                val modelUrl = response.optString("modelUrl", "")
                if (!modelUrl.startsWith("https://")) throw IllegalStateException(response.optString("error", "AI service did not return a GLB model URL"))
                val file = File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir, "Noor3D_Model_${System.currentTimeMillis()}.glb")
                URL(modelUrl).openStream().use { input -> file.outputStream().use { output -> input.copyTo(output) } }
                runOnUiThread { status.text = "3D model generated and downloaded: ${file.name}. File location: Android/data/com.noor3d.studio/files/Download. Import/rigged animation preview is not yet built into this version." }
            } catch (e: Exception) {
                runOnUiThread { status.text = "AI 3D model failed: ${e.message ?: "network/provider error"}" }
            } finally { runOnUiThread { aiVideoButton.isEnabled = true; aiModelButton.isEnabled = true } }
        }.start()
    }

    private fun postJson(endpoint: String, body: JSONObject): JSONObject {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 20_000; readTimeout = 900_000
            doOutput = true; setRequestProperty("Content-Type", "application/json; charset=utf-8")
            val token = aiServerToken.text.toString().trim()
            if (token.isNotEmpty()) setRequestProperty("Authorization", "Bearer $token")
        }
        try {
            connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
            val json = JSONObject(text)
            if (code !in 200..299) throw IllegalStateException(json.optString("error", "Backend HTTP $code"))
            return json
        } finally { connection.disconnect() }
    }

    private fun saveToMovies(file: File): Uri {
        val resolver = contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "Noor3D_${System.currentTimeMillis()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= 29) put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Noor3D")
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: throw IllegalStateException("Could not create video in Movies/Noor3D")
        try {
            resolver.openOutputStream(uri)?.use { output -> FileInputStream(file).use { input -> input.copyTo(output) } }
                ?: throw IllegalStateException("Could not open output video")
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        return uri
    }

    private fun updateLanguage() {
        // Keep the selected prompt intact; rebuild labels without resetting the preview.
        titleLanguageRefresh()
    }
    private fun titleLanguageRefresh() {
        status.text = if (urdu) "زبان اردو منتخب ہے۔" else "English selected."
        generateButton.text = if (urdu) "✦ کہانی سے اینیمیشن تیار کریں" else "✦ Build animation from prompt"
        exportButton.text = if (urdu) "⬇ 720p MP4 ویڈیو بنائیں" else "⬇ Export 720p MP4 video"
        durationLabel.text = durationText()
    }
    private fun durationText() = if (urdu) "ویڈیو کا دورانیہ: $durationSeconds سیکنڈ (2 منٹ تک)" else "Video duration: $durationSeconds seconds (up to 2 minutes)"
    private fun sectionTitle(text: String) = TextView(this).apply { this.text = text; textSize = 15f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; setPadding(dp(2), dp(5), dp(2), dp(8)) }
    private fun button(text: String, action: (View) -> Unit) = Button(this).apply {
        this.text = text
        textSize = 12f
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(64, 82, 174)))
        setOnClickListener(action)
    }
    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items).also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        setBackgroundColor(Color.rgb(26, 37, 59))
    }
    private fun dp(value: Int) = (value * resources.displayMetrics.density + 0.5f).toInt()

    override fun onInit(statusCode: Int) {
        ttsReady = statusCode == TextToSpeech.SUCCESS
        if (ttsReady) tts?.setLanguage(Locale.US)
    }
    override fun onPause() { super.onPause(); if (::scene.isInitialized) scene.onPause() }
    override fun onResume() { super.onResume(); if (::scene.isInitialized) scene.onResume() }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}
