package com.noor3d.studio

import android.content.Context
import android.graphics.Color
import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMuxer
import android.opengl.EGL14
import android.opengl.EGLExt
import android.opengl.GLES20
import android.opengl.Matrix
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import kotlin.math.cos
import kotlin.math.sin

/** Encodes the animated OpenGL ES 2.0 3D scene to an actual H.264 MP4 file. */
class Mp4AnimationExporter(private val context: Context) {
    companion object {
        private const val WIDTH = 1280
        private const val HEIGHT = 720
        private const val FPS = 30
        private const val MIME = "video/avc"
        private const val EGL_OPENGL_ES2_BIT = 4
        private const val EGL_CONTEXT_CLIENT_VERSION = 0x3098
        private const val EGL_RECORDABLE_ANDROID = 0x3142
    }

    fun export(output: File, seconds: Int, scene: Int, prompt: String, progress: (Int, Int) -> Unit) {
        require(seconds in 2..120) { "Duration must be between 2 and 120 seconds" }
        output.parentFile?.mkdirs()
        val totalFrames = seconds * FPS
        val format = MediaFormat.createVideoFormat(MIME, WIDTH, HEIGHT).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, 0x7F000789) // COLOR_FormatSurface
            setInteger(MediaFormat.KEY_BIT_RATE, 4_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
        val encoder = MediaCodec.createEncoderByType(MIME)
        var inputSurface: Surface? = null
        var muxer: MediaMuxer? = null
        var eglDisplay = EGL14.EGL_NO_DISPLAY
        var eglContext = EGL14.EGL_NO_CONTEXT
        var eglSurface = EGL14.EGL_NO_SURFACE
        var muxerStarted = false
        var outputEos = false
        try {
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val activeSurface = encoder.createInputSurface()
            inputSurface = activeSurface
            encoder.start()
            val activeMuxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = activeMuxer

            val egl = createEgl(activeSurface)
            eglDisplay = egl[0] as android.opengl.EGLDisplay
            eglContext = egl[1] as android.opengl.EGLContext
            eglSurface = egl[2] as android.opengl.EGLSurface
            val renderer = ThreeDFrameRenderer(WIDTH, HEIGHT)
            renderer.initialize()
            val info = MediaCodec.BufferInfo()
            var trackIndex = -1

            for (frame in 0 until totalFrames) {
                val t = frame.toFloat() / FPS
                renderer.drawFrame(t, scene, prompt)
                EGLExt.eglPresentationTimeANDROID(eglDisplay, eglSurface, frame * 1_000_000_000L / FPS)
                if (!EGL14.eglSwapBuffers(eglDisplay, eglSurface)) throw IllegalStateException("Could not submit 3D frame to video encoder")

                var keepDraining = true
                while (keepDraining) {
                    val index = encoder.dequeueOutputBuffer(info, 0)
                    when {
                        index == MediaCodec.INFO_TRY_AGAIN_LATER -> keepDraining = false
                        index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            if (muxerStarted) throw IllegalStateException("Encoder output format changed twice")
                            trackIndex = activeMuxer.addTrack(encoder.outputFormat)
                            activeMuxer.start()
                            muxerStarted = true
                        }
                        index >= 0 -> {
                            val buffer = encoder.getOutputBuffer(index) ?: throw IllegalStateException("Encoder returned an empty output buffer")
                            if (info.size > 0) {
                                if (!muxerStarted) throw IllegalStateException("MP4 muxer did not start")
                                buffer.position(info.offset)
                                buffer.limit(info.offset + info.size)
                                activeMuxer.writeSampleData(trackIndex, buffer, info)
                            }
                            outputEos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                            encoder.releaseOutputBuffer(index, false)
                            if (outputEos) keepDraining = false
                        }
                    }
                }
                if (frame % FPS == 0 || frame == totalFrames - 1) progress(frame + 1, totalFrames)
            }

            encoder.signalEndOfInputStream()
            while (!outputEos) {
                val index = encoder.dequeueOutputBuffer(info, 10_000)
                when {
                    index == MediaCodec.INFO_TRY_AGAIN_LATER -> continue
                    index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        if (muxerStarted) throw IllegalStateException("Encoder output format changed twice")
                        trackIndex = activeMuxer.addTrack(encoder.outputFormat)
                        activeMuxer.start()
                        muxerStarted = true
                    }
                    index >= 0 -> {
                        val buffer = encoder.getOutputBuffer(index) ?: throw IllegalStateException("Encoder returned an empty output buffer")
                        if (info.size > 0) {
                            if (!muxerStarted) throw IllegalStateException("MP4 muxer did not start")
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            activeMuxer.writeSampleData(trackIndex, buffer, info)
                        }
                        outputEos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        encoder.releaseOutputBuffer(index, false)
                    }
                }
            }
            if (!muxerStarted) throw IllegalStateException("No encoded video frames were produced")
        } finally {
            if (eglDisplay != EGL14.EGL_NO_DISPLAY) {
                try { EGL14.eglMakeCurrent(eglDisplay, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT) } catch (_: Exception) {}
                if (eglSurface != EGL14.EGL_NO_SURFACE) try { EGL14.eglDestroySurface(eglDisplay, eglSurface) } catch (_: Exception) {}
                if (eglContext != EGL14.EGL_NO_CONTEXT) try { EGL14.eglDestroyContext(eglDisplay, eglContext) } catch (_: Exception) {}
                try { EGL14.eglTerminate(eglDisplay) } catch (_: Exception) {}
            }
            try { encoder.stop() } catch (_: Exception) {}
            try { encoder.release() } catch (_: Exception) {}
            try { inputSurface?.release() } catch (_: Exception) {}
            try { if (muxerStarted) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
        if (!output.exists() || output.length() < 4096) throw IllegalStateException("MP4 output is missing or too small")
    }

    private fun createEgl(surface: Surface): Array<Any> {
        val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        if (display == EGL14.EGL_NO_DISPLAY) throw IllegalStateException("Could not get EGL display")
        val versions = IntArray(2)
        if (!EGL14.eglInitialize(display, versions, 0, versions, 1)) throw IllegalStateException("Could not initialize EGL")
        val attrs = intArrayOf(
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_DEPTH_SIZE, 16,
            EGL14.EGL_RENDERABLE_TYPE, EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE, EGL14.EGL_WINDOW_BIT,
            EGL_RECORDABLE_ANDROID, 1, EGL14.EGL_NONE
        )
        val configs = arrayOfNulls<android.opengl.EGLConfig>(1)
        val count = IntArray(1)
        if (!EGL14.eglChooseConfig(display, attrs, 0, configs, 0, configs.size, count, 0) || count[0] == 0) throw IllegalStateException("No EGL config supports video encoding")
        val contextAttrs = intArrayOf(EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE)
        val config = configs[0] ?: throw IllegalStateException("No compatible EGL config")
        val context = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT, contextAttrs, 0)
        if (context == EGL14.EGL_NO_CONTEXT) throw IllegalStateException("Could not create OpenGL context")
        val surfaceAttrs = intArrayOf(EGL14.EGL_NONE)
        val eglSurface = EGL14.eglCreateWindowSurface(display, config, surface, surfaceAttrs, 0)
        if (eglSurface == EGL14.EGL_NO_SURFACE) throw IllegalStateException("Could not create EGL video surface")
        if (!EGL14.eglMakeCurrent(display, eglSurface, eglSurface, context)) throw IllegalStateException("Could not activate EGL video surface")
        return arrayOf(display, context, eglSurface)
    }

    private class ThreeDFrameRenderer(private val width: Int, private val height: Int) {
        private var program = 0
        private var positionHandle = 0
        private var colorHandle = 0
        private var mvpHandle = 0
        private val projection = FloatArray(16)
        private val view = FloatArray(16)
        private val model = FloatArray(16)
        private val vp = FloatArray(16)
        private val mvp = FloatArray(16)
        private lateinit var cube: FloatBuffer
        private val vertexShader = """
            uniform mat4 uMVP;
            attribute vec3 aPosition;
            void main() { gl_Position = uMVP * vec4(aPosition, 1.0); }
        """.trimIndent()
        private val fragmentShader = """
            precision mediump float;
            uniform vec4 uColor;
            void main() { gl_FragColor = uColor; }
        """.trimIndent()

        fun initialize() {
            GLES20.glViewport(0, 0, width, height)
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            program = createProgram(vertexShader, fragmentShader)
            positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
            colorHandle = GLES20.glGetUniformLocation(program, "uColor")
            mvpHandle = GLES20.glGetUniformLocation(program, "uMVP")
            cube = ByteBuffer.allocateDirect(CUBE.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(CUBE); position(0) }
            Matrix.perspectiveM(projection, 0, 42f, width.toFloat() / height, 0.1f, 100f)
            Matrix.setLookAtM(view, 0, 0f, 4.0f, 10.5f, 0f, 1.2f, 0f, 0f, 1f, 0f)
            Matrix.multiplyMM(vp, 0, projection, 0, view, 0)
        }

        fun drawFrame(time: Float, scene: Int, prompt: String) {
            when (scene) {
                1 -> GLES20.glClearColor(0.09f, 0.13f, 0.25f, 1f)
                2 -> GLES20.glClearColor(0.015f, 0.02f, 0.10f, 1f)
                3 -> GLES20.glClearColor(0.18f, 0.20f, 0.29f, 1f)
                else -> GLES20.glClearColor(0.40f, 0.68f, 0.88f, 1f)
            }
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
            GLES20.glUseProgram(program)
            when (scene) {
                0 -> {
                    drawCube(0f, -0.12f, 0f, 9f, 0.18f, 9f, floatArrayOf(0.18f, 0.45f, 0.22f, 1f))
                    for (i in -3..3) {
                        if (i == 0) continue
                        drawCube(i * 1.55f, 0.62f, -2.5f, 0.22f, 1.1f, 0.22f, floatArrayOf(0.32f, 0.20f, 0.10f, 1f))
                        drawCube(i * 1.55f, 1.42f, -2.5f, 0.95f, 0.9f, 0.9f, floatArrayOf(0.12f, 0.43f, 0.18f, 1f))
                    }
                }
                1 -> {
                    drawCube(0f, -0.12f, 0f, 10f, 0.18f, 9f, floatArrayOf(0.18f, 0.20f, 0.27f, 1f))
                    for (i in -4..4) {
                        val h = 1.2f + ((i * i + 2) % 4) * 0.45f
                        drawCube(i * 1.3f, h / 2f, -2.8f, 0.85f, h, 0.85f, floatArrayOf(0.20f, 0.25f, 0.37f, 1f))
                        for (row in 0..2) drawCube(i * 1.3f, 0.25f + row * 0.3f, -2.32f, 0.12f, 0.12f, 0.04f, floatArrayOf(0.98f, 0.75f, 0.32f, 1f))
                    }
                }
                2 -> {
                    drawCube(0f, -0.15f, 0f, 10f, 0.18f, 9f, floatArrayOf(0.07f, 0.09f, 0.24f, 1f))
                    drawCube(2.5f, 2.7f, -3.0f, 1.5f, 1.5f, 1.5f, floatArrayOf(0.38f, 0.35f, 0.80f, 1f), time * 0.2f)
                    for (i in -4..4) drawCube(i * 1.0f, 3.2f + (i % 2) * 0.3f, -4f, 0.04f, 0.04f, 0.04f, floatArrayOf(1f, 1f, 1f, 1f))
                }
                else -> {
                    drawCube(0f, -0.12f, 0f, 9f, 0.18f, 9f, floatArrayOf(0.24f, 0.27f, 0.38f, 1f))
                    drawCube(0f, 2.4f, -2.4f, 5.8f, 3.7f, 0.25f, floatArrayOf(0.28f, 0.32f, 0.48f, 1f))
                    drawCube(-2.6f, 2.0f, -2.1f, 0.12f, 2.5f, 0.12f, floatArrayOf(0.70f, 0.75f, 0.90f, 1f))
                    drawCube(2.6f, 2.0f, -2.1f, 0.12f, 2.5f, 0.12f, floatArrayOf(0.70f, 0.75f, 0.90f, 1f))
                }
            }
            val lower = prompt.lowercase()
            val walk = when { lower.contains("run") || prompt.contains("دوڑ") -> sin(time * 9f) * 0.75f; else -> sin(time * 5f) * 0.42f }
            val jump = if (lower.contains("jump") || prompt.contains("چھلانگ")) kotlin.math.abs(sin(time * 3f)) * 0.65f else 0f
            val wave = if (lower.contains("wave") || prompt.contains("ہاتھ ہلا")) sin(time * 5f) * 0.8f else 0f
            val bob = cos(time * 10f) * 0.06f + jump
            drawCube(0f, 1.15f + bob, 0f, 0.78f, 1.05f, 0.42f, floatArrayOf(0.12f, 0.30f, 0.82f, 1f))
            drawCube(0f, 1.95f + bob, 0f, 0.58f, 0.58f, 0.55f, floatArrayOf(0.78f, 0.55f, 0.36f, 1f))
            drawCube(-0.48f, 1.18f + bob, 0f, 0.22f, 0.86f, 0.24f, floatArrayOf(0.78f, 0.55f, 0.36f, 1f), if (wave != 0f) -1.5f + wave else walk)
            drawCube(0.48f, 1.18f + bob, 0f, 0.22f, 0.86f, 0.24f, floatArrayOf(0.78f, 0.55f, 0.36f, 1f), -walk)
            drawCube(-0.23f, 0.48f + bob, 0f, 0.25f, 0.88f, 0.28f, floatArrayOf(0.18f, 0.20f, 0.28f, 1f), walk)
            drawCube(0.23f, 0.48f + bob, 0f, 0.25f, 0.88f, 0.28f, floatArrayOf(0.18f, 0.20f, 0.28f, 1f), -walk)
        }

        private fun drawCube(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, color: FloatArray, rotation: Float = 0f) {
            Matrix.setIdentityM(model, 0)
            Matrix.translateM(model, 0, x, y, z)
            if (rotation != 0f) Matrix.rotateM(model, 0, rotation * 57.29578f, 0f, 0f, 1f)
            Matrix.scaleM(model, 0, sx, sy, sz)
            Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
            GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvp, 0)
            GLES20.glUniform4fv(colorHandle, 1, color, 0)
            cube.position(0)
            GLES20.glEnableVertexAttribArray(positionHandle)
            GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, cube)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, CUBE.size / 3)
            GLES20.glDisableVertexAttribArray(positionHandle)
        }

        private fun createProgram(vertex: String, fragment: String): Int {
            fun compile(type: Int, source: String): Int {
                val shader = GLES20.glCreateShader(type)
                GLES20.glShaderSource(shader, source)
                GLES20.glCompileShader(shader)
                val status = IntArray(1)
                GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
                if (status[0] == 0) throw IllegalStateException("OpenGL shader compile failed: ${GLES20.glGetShaderInfoLog(shader)}")
                return shader
            }
            val p = GLES20.glCreateProgram()
            GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vertex))
            GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fragment))
            GLES20.glLinkProgram(p)
            val status = IntArray(1)
            GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, status, 0)
            if (status[0] == 0) throw IllegalStateException("OpenGL program link failed: ${GLES20.glGetProgramInfoLog(p)}")
            return p
        }

        companion object {
            private val CUBE = floatArrayOf(
                -0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f,
                0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f,
                -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f,
                0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f,
                -0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f,
                -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f
            )
        }
    }
}
