package com.noor3d.studio

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Creates narration with Android TTS, encodes it as AAC, and muxes it into the rendered MP4. */
class NarrationMuxer {
    fun synthesizeAndMux(tts: TextToSpeech, narration: String, wavFile: File, silentVideo: File, audioOnlyMp4: File, finalMp4: File, durationSeconds: Int) {
        synthesize(tts, narration, wavFile)
        encodeWavToAacMp4(wavFile, audioOnlyMp4, durationSeconds)
        muxTracks(silentVideo, audioOnlyMp4, finalMp4)
        if (!finalMp4.exists() || finalMp4.length() < 4096) throw IllegalStateException("Final video with narration was not created")
    }

    private fun synthesize(tts: TextToSpeech, text: String, output: File) {
        val done = CountDownLatch(1)
        val failed = AtomicBoolean(false)
        val utteranceId = "noor3d-export-${System.currentTimeMillis()}"
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceIdValue: String?) {}
            override fun onDone(utteranceIdValue: String?) { if (utteranceIdValue == utteranceId) done.countDown() }
            @Deprecated("Deprecated in Android API")
            override fun onError(utteranceIdValue: String?) { if (utteranceIdValue == utteranceId) { failed.set(true); done.countDown() } }
            override fun onError(utteranceIdValue: String?, errorCode: Int) { if (utteranceIdValue == utteranceId) { failed.set(true); done.countDown() } }
        })
        output.delete()
        val result = tts.synthesizeToFile(text, android.os.Bundle(), output, utteranceId)
        if (result != TextToSpeech.SUCCESS) throw IllegalStateException("The phone's text-to-speech engine could not create narration")
        if (!done.await(120, TimeUnit.SECONDS)) throw IllegalStateException("Timed out while creating narration audio")
        if (failed.get() || !output.exists() || output.length() < 48) throw IllegalStateException("Narration audio could not be generated. Check the phone's TTS voice settings.")
    }

    private data class WavData(val pcm: ByteArray, val sampleRate: Int, val channels: Int, val bits: Int)

    private fun readWav(file: File): WavData {
        val bytes = FileInputStream(file).use { it.readBytes() }
        if (bytes.size < 44 || ascii(bytes, 0, 4) != "RIFF" || ascii(bytes, 8, 4) != "WAVE") throw IllegalStateException("TTS engine did not return a supported WAV file")
        val header = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
        val formatTag = header.getShort(20).toInt() and 0xffff
        val channels = header.getShort(22).toInt() and 0xffff
        val sampleRate = header.getInt(24)
        val bits = header.getShort(34).toInt() and 0xffff
        if (formatTag != 1 || channels !in 1..2 || sampleRate !in 8000..48000 || bits != 16) throw IllegalStateException("TTS WAV format is not supported (expected 16-bit PCM)")
        var offset = 12
        var dataStart = -1
        var dataSize = 0
        while (offset + 8 <= bytes.size) {
            val chunkName = ascii(bytes, offset, 4)
            val chunkSize = header.getInt(offset + 4).coerceAtLeast(0)
            if (chunkName == "data") { dataStart = offset + 8; dataSize = minOf(chunkSize, bytes.size - dataStart); break }
            offset += 8 + chunkSize + (chunkSize and 1)
        }
        if (dataStart < 0 || dataSize <= 0) throw IllegalStateException("No PCM audio data was found in the narration WAV")
        return WavData(bytes.copyOfRange(dataStart, dataStart + dataSize), sampleRate, channels, bits)
    }

    private data class AudioDrainState(var started: Boolean = false, var track: Int = -1, var eos: Boolean = false)

    private fun encodeWavToAacMp4(wav: File, output: File, durationSeconds: Int) {
        val wavData = readWav(wav)
        val bytesPerFrame = wavData.channels * 2
        val targetBytes = durationSeconds.toLong() * wavData.sampleRate * bytesPerFrame
        val pcm = ByteArray(targetBytes.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
        System.arraycopy(wavData.pcm, 0, pcm, 0, minOf(wavData.pcm.size, pcm.size)) // Remaining bytes are silence.
        val format = MediaFormat.createAudioFormat("audio/mp4a-latm", wavData.sampleRate, wavData.channels).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, 2) // AAC-LC
            setInteger(MediaFormat.KEY_BIT_RATE, 96000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val encoder = MediaCodec.createEncoderByType("audio/mp4a-latm")
        var muxer: MediaMuxer? = null
        val state = AudioDrainState()
        try {
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()
            val activeMuxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = activeMuxer
            val info = MediaCodec.BufferInfo()
            var offset = 0
            val chunkBytes = 4096 - (4096 % bytesPerFrame)
            while (offset < pcm.size) {
                val inputIndex = encoder.dequeueInputBuffer(10_000)
                if (inputIndex >= 0) {
                    val input = encoder.getInputBuffer(inputIndex) ?: throw IllegalStateException("AAC encoder input buffer unavailable")
                    input.clear()
                    val count = minOf(input.remaining(), chunkBytes, pcm.size - offset)
                    input.put(pcm, offset, count)
                    val framesQueued = offset / bytesPerFrame
                    val ptsUs = framesQueued.toLong() * 1_000_000L / wavData.sampleRate
                    offset += count
                    encoder.queueInputBuffer(inputIndex, 0, count, ptsUs, 0)
                }
                drainAac(encoder, activeMuxer, info, state, 0)
            }
            var eosQueued = false
            while (!eosQueued) {
                val inputIndex = encoder.dequeueInputBuffer(10_000)
                if (inputIndex >= 0) {
                    val ptsUs = (pcm.size / bytesPerFrame).toLong() * 1_000_000L / wavData.sampleRate
                    encoder.queueInputBuffer(inputIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    eosQueued = true
                } else {
                    drainAac(encoder, activeMuxer, info, state, 10_000)
                }
            }
            while (!state.eos) drainAac(encoder, activeMuxer, info, state, 10_000)
            if (!state.started) throw IllegalStateException("Narration AAC track was not created")
        } finally {
            try { encoder.stop() } catch (_: Exception) {}
            try { encoder.release() } catch (_: Exception) {}
            try { if (state.started) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }
    }

    private fun drainAac(encoder: MediaCodec, muxer: MediaMuxer, info: MediaCodec.BufferInfo, state: AudioDrainState, timeoutUs: Long) {
        while (true) {
            val index = encoder.dequeueOutputBuffer(info, timeoutUs)
            when {
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> return
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    if (state.started) throw IllegalStateException("AAC encoder format changed twice")
                    state.track = muxer.addTrack(encoder.outputFormat)
                    muxer.start()
                    state.started = true
                }
                index >= 0 -> {
                    val buffer = encoder.getOutputBuffer(index) ?: throw IllegalStateException("AAC output buffer unavailable")
                    if (info.size > 0) {
                        if (!state.started || state.track < 0) throw IllegalStateException("AAC muxer did not start")
                        buffer.position(info.offset); buffer.limit(info.offset + info.size)
                        muxer.writeSampleData(state.track, buffer, info)
                    }
                    state.eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    encoder.releaseOutputBuffer(index, false)
                    if (state.eos) return
                }
            }
        }
    }

    private fun muxTracks(videoFile: File, audioFile: File, output: File) {
        val video = MediaExtractor(); video.setDataSource(videoFile.absolutePath)
        val audio = MediaExtractor(); audio.setDataSource(audioFile.absolutePath)
        var videoTrack = -1; var audioTrack = -1
        for (i in 0 until video.trackCount) if (video.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true) { videoTrack = i; break }
        for (i in 0 until audio.trackCount) if (audio.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) { audioTrack = i; break }
        if (videoTrack < 0 || audioTrack < 0) { video.release(); audio.release(); throw IllegalStateException("Could not find video and narration tracks") }
        val muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        try {
            val outVideoTrack = muxer.addTrack(video.getTrackFormat(videoTrack))
            val outAudioTrack = muxer.addTrack(audio.getTrackFormat(audioTrack))
            muxer.start()
            copyTrack(video, videoTrack, muxer, outVideoTrack)
            copyTrack(audio, audioTrack, muxer, outAudioTrack)
        } finally {
            try { muxer.stop() } catch (_: Exception) {}
            muxer.release(); video.release(); audio.release()
        }
    }

    private fun copyTrack(extractor: MediaExtractor, sourceTrack: Int, muxer: MediaMuxer, targetTrack: Int) {
        extractor.selectTrack(sourceTrack)
        val buffer = ByteBuffer.allocate(1 shl 20)
        val info = MediaCodec.BufferInfo()
        while (true) {
            buffer.clear()
            val size = extractor.readSampleData(buffer, 0)
            if (size < 0) break
            info.offset = 0; info.size = size; info.presentationTimeUs = extractor.sampleTime
            info.flags = extractor.sampleFlags
            muxer.writeSampleData(targetTrack, buffer, info)
            extractor.advance()
        }
        extractor.unselectTrack(sourceTrack)
    }

    private fun ascii(bytes: ByteArray, offset: Int, length: Int) = String(bytes, offset, length, Charsets.US_ASCII)
}
