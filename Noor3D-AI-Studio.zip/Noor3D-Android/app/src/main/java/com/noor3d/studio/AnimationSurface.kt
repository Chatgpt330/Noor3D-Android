package com.noor3d.studio

import android.content.Context
import android.opengl.GLSurfaceView
import android.opengl.GLES20
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

/** A real OpenGL ES 2.0 scene prototype made from 3D geometry, not a slideshow. */
class AnimationSurface(context: Context) : GLSurfaceView(context) {
    private val sceneRenderer = SceneRenderer()
    init {
        setEGLContextClientVersion(2)
        setRenderer(sceneRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }
    fun setPlaying(value: Boolean) { sceneRenderer.playing = value }
    fun resetAnimation() { sceneRenderer.elapsed = 0f; sceneRenderer.playing = true }
    fun setScene(value: Int) { sceneRenderer.scene = value }
    fun setPrompt(value: String) { sceneRenderer.prompt = value }
}

private class SceneRenderer : GLSurfaceView.Renderer {
    @Volatile var playing = true
    @Volatile var elapsed = 0f
    @Volatile var scene = 0
    @Volatile var prompt = ""
    private var program = 0
    private var positionHandle = 0
    private var colorHandle = 0
    private var mvpHandle = 0
    private lateinit var cube: FloatBuffer
    private val projection = FloatArray(16)
    private val view = FloatArray(16)
    private val model = FloatArray(16)
    private val vp = FloatArray(16)
    private val mvp = FloatArray(16)
    private var lastNs = 0L

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.40f, 0.68f, 0.88f, 1f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        val vertexShader = """
            uniform mat4 uMVP;
            attribute vec3 aPosition;
            void main() { gl_Position = uMVP * vec4(aPosition, 1.0); }
        """.trimIndent()
        val fragmentShader = """
            precision mediump float;
            uniform vec4 uColor;
            void main() { gl_FragColor = uColor; }
        """.trimIndent()
        program = createProgram(vertexShader, fragmentShader)
        positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
        colorHandle = GLES20.glGetUniformLocation(program, "uColor")
        mvpHandle = GLES20.glGetUniformLocation(program, "uMVP")
        cube = ByteBuffer.allocateDirect(CUBE.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(CUBE); position(0) }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / height.coerceAtLeast(1)
        Matrix.perspectiveM(projection, 0, 52f, ratio, 0.1f, 100f)
        Matrix.setLookAtM(view, 0, 0f, 4.2f, 11.5f, 0f, 1.1f, 0f, 0f, 1f, 0f)
        Matrix.multiplyMM(vp, 0, projection, 0, view, 0)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        if (lastNs != 0L && playing) elapsed += ((now - lastNs) / 1_000_000_000f).coerceAtMost(0.05f)
        lastNs = now
        when (scene) {
            1 -> GLES20.glClearColor(0.09f, 0.13f, 0.25f, 1f)
            2 -> GLES20.glClearColor(0.015f, 0.02f, 0.10f, 1f)
            3 -> GLES20.glClearColor(0.18f, 0.20f, 0.29f, 1f)
            else -> GLES20.glClearColor(0.40f, 0.68f, 0.88f, 1f)
        }
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        GLES20.glUseProgram(program)
        when (scene) {
            0 -> {
                drawCube(0f, -0.12f, 0f, 8f, 0.18f, 8f, floatArrayOf(0.20f, 0.48f, 0.25f, 1f))
                for (i in -3..3) {
                    if (i == 0) continue
                    drawCube(i * 1.15f, 0.62f, -2.1f, 0.22f, 1.1f, 0.22f, floatArrayOf(0.32f, 0.20f, 0.10f, 1f))
                    drawCube(i * 1.15f, 1.42f, -2.1f, 0.95f, 0.9f, 0.9f, floatArrayOf(0.12f, 0.43f, 0.18f, 1f))
                }
            }
            1 -> {
                drawCube(0f, -0.12f, 0f, 8f, 0.18f, 8f, floatArrayOf(0.18f, 0.20f, 0.27f, 1f))
                for (i in -3..3) drawCube(i * 1.15f, 1.0f + (i % 2) * 0.3f, -2.1f, 0.8f, 2.0f + (i % 3) * 0.4f, 0.8f, floatArrayOf(0.20f, 0.25f, 0.37f, 1f))
            }
            2 -> {
                drawCube(0f, -0.12f, 0f, 8f, 0.18f, 8f, floatArrayOf(0.07f, 0.09f, 0.24f, 1f))
                drawCube(2.3f, 2.6f, -3f, 1.5f, 1.5f, 1.5f, floatArrayOf(0.38f, 0.35f, 0.80f, 1f), elapsed * 0.2f)
                for (i in -3..3) drawCube(i * 1.0f, 3.2f + (i % 2) * 0.3f, -4f, 0.04f, 0.04f, 0.04f, floatArrayOf(1f, 1f, 1f, 1f))
            }
            else -> {
                drawCube(0f, -0.12f, 0f, 8f, 0.18f, 8f, floatArrayOf(0.24f, 0.27f, 0.38f, 1f))
                drawCube(0f, 2.4f, -2.4f, 5.8f, 3.7f, 0.25f, floatArrayOf(0.28f, 0.32f, 0.48f, 1f))
            }
        }
        val lower = prompt.lowercase()
        val walk = if (lower.contains("run") || prompt.contains("دوڑ")) sin(elapsed * 9f) * 0.75f else sin(elapsed * 5f) * 0.42f
        val jump = if (lower.contains("jump") || prompt.contains("چھلانگ")) kotlin.math.abs(sin(elapsed * 3f)) * 0.65f else 0f
        val wave = if (lower.contains("wave") || prompt.contains("ہاتھ ہلا")) sin(elapsed * 5f) * 0.8f else 0f
        val bob = cos(elapsed * 10f) * 0.06f + jump
        drawCube(0f, 1.15f + bob, 0f, 0.78f, 1.05f, 0.42f, floatArrayOf(0.12f, 0.30f, 0.82f, 1f))
        drawCube(0f, 1.95f + bob, 0f, 0.58f, 0.58f, 0.55f, floatArrayOf(0.78f, 0.55f, 0.36f, 1f))
        drawCube(-0.48f, 1.18f + bob, 0f, 0.22f, 0.86f, 0.24f, floatArrayOf(0.78f, 0.55f, 0.36f, 1f), if (wave != 0f) -1.5f + wave else walk)
        drawCube(0.48f, 1.18f + bob, 0f, 0.22f, 0.86f, 0.24f, floatArrayOf(0.78f, 0.55f, 0.36f, 1f), -walk)
        drawCube(-0.23f, 0.48f + bob, 0f, 0.25f, 0.88f, 0.28f, floatArrayOf(0.18f, 0.20f, 0.28f, 1f), walk)
        drawCube(0.23f, 0.48f + bob, 0f, 0.25f, 0.88f, 0.28f, floatArrayOf(0.18f, 0.20f, 0.28f, 1f), -walk)
    }

    private fun drawCube(x: Float, y: Float, z: Float, sx: Float, sy: Float, sz: Float, color: FloatArray, rotation: Float = 0f) {
        Matrix.setIdentityM(model, 0)
        Matrix.translateM(model, 0, x, y, z)
        if (rotation != 0f) Matrix.rotateM(model, 0, rotation * 57.29578f, 0f, 0f, 1f)
        Matrix.scaleM(model, 0, sx, sy, sz)
        Matrix.multiplyMM(mvp, 0, vp, 0, model, 0)
        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvp, 0)
        GLES20.glUniform4fv(colorHandle, 1, color, 0)
        cube.position(0)
        GLES20.glEnableVertexAttribArray(positionHandle)
        GLES20.glVertexAttribPointer(positionHandle, 3, GLES20.GL_FLOAT, false, 0, cube)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, CUBE.size / 3)
        GLES20.glDisableVertexAttribArray(positionHandle)
    }

    private fun createProgram(vertex: String, fragment: String): Int {
        fun compile(type: Int, source: String): Int {
            val shader = GLES20.glCreateShader(type)
            GLES20.glShaderSource(shader, source)
            GLES20.glCompileShader(shader)
            val status = IntArray(1)
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
            if (status[0] == 0) throw IllegalStateException("Shader compile failed: " + GLES20.glGetShaderInfoLog(shader))
            return shader
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, compile(GLES20.GL_VERTEX_SHADER, vertex))
        GLES20.glAttachShader(p, compile(GLES20.GL_FRAGMENT_SHADER, fragment))
        GLES20.glLinkProgram(p)
        val status = IntArray(1)
        GLES20.glGetProgramiv(p, GLES20.GL_LINK_STATUS, status, 0)
        if (status[0] == 0) throw IllegalStateException("Program link failed: " + GLES20.glGetProgramInfoLog(p))
        return p
    }

    companion object {
        private val CUBE = floatArrayOf(
            -0.5f,-0.5f, 0.5f, 0.5f,-0.5f, 0.5f, 0.5f,0.5f,0.5f, -0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f,
            0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f,
            0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f,
            -0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f
        )
    }
}
