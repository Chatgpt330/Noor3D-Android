plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.noor3d.studio"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.noor3d.studio"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.3-ai-alpha"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
