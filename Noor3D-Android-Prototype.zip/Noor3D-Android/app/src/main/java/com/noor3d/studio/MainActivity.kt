package com.noor3d.studio

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var scene: AnimationSurface
    private lateinit var title: TextView
    private lateinit var playButton: Button
    private lateinit var languageButton: Button
    private var urdu = true
    private var playing = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
        scene = AnimationSurface(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(14, 21, 35))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(16, 8, 16, 8)
            setBackgroundColor(Color.rgb(20, 30, 48))
        }
        title = TextView(this).apply { textSize = 18f; setTextColor(Color.WHITE); text = "نور 3D — اینیمیشن اسٹوڈیو" }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        languageButton = Button(this).apply { text = "اردو / English"; setOnClickListener { urdu = !urdu; updateLabels() } }
        header.addView(languageButton)
        root.addView(header)
        root.addView(scene, LinearLayout.LayoutParams(-1, 0, 1f))

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(8, 4, 8, 8)
            setBackgroundColor(Color.rgb(20, 30, 48))
        }
        playButton = Button(this).apply { setOnClickListener { playing = !playing; scene.setPlaying(playing); updateLabels() } }
        val reset = Button(this).apply {
            text = if (urdu) "دوبارہ شروع" else "Reset"
            setOnClickListener { scene.resetAnimation(); playing = true; scene.setPlaying(true); updateLabels() }
        }
        val export = Button(this).apply {
            text = if (urdu) "ویڈیو ایکسپورٹ — اگلا مرحلہ" else "Video export — next phase"
            setOnClickListener { Toast.makeText(this@MainActivity, if (urdu) "یہ پروٹوٹائپ صرف 3D منظر اور حرکت دکھاتا ہے۔ MP4 ایکسپورٹ اگلے مرحلے میں بنایا جائے گا۔" else "This prototype previews 3D motion. MP4 export is planned for the next phase.", Toast.LENGTH_LONG).show() }
        }
        controls.addView(playButton)
        controls.addView(reset)
        controls.addView(export)
        root.addView(controls)
        setContentView(root)
        updateLabels()
    }

    private fun updateLabels() {
        title.text = if (urdu) "نور 3D — اینیمیشن اسٹوڈیو" else "Noor3D — Animation Studio"
        playButton.text = if (playing) { if (urdu) "⏸ روکیں" else "⏸ Pause" } else { if (urdu) "▶ چلائیں" else "▶ Play" }
    }

    override fun onPause() { super.onPause(); if (::scene.isInitialized) scene.onPause() }
    override fun onResume() { super.onResume(); if (::scene.isInitialized) scene.onResume() }
}
