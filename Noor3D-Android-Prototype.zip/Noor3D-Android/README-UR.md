# Noor3D — Android 3D Animation Maker (ابتدائی پروٹوٹائپ)

یہ نیا، الگ Android project ہے۔ اس میں OpenGL ES 2.0 کے ذریعے حقیقی 3D geometry اور چلنے والی procedural animation کا ابتدائی منظر ہے۔ یہ ابھی مکمل animation editor نہیں ہے۔

## اس ورژن میں کیا ہے؟
- Android app shell، landscape preview
- OpenGL ES 2.0 پر 3D منظر: زمین، درخت، اور blocks سے بنایا ہوا متحرک character
- Play/Pause اور Reset
- اردو/English UI toggle
- GitHub Actions workflow جو debug APK build کرنے کی کوشش کرے گا

## ابھی کیا شامل نہیں؟
- MP4 video export
- prompt-to-scene AI
- skeletal 3D character assets
- AI Urdu/English male/female voice generation
- مکمل timeline/editor

ان فیچرز کو الگ مراحل میں implement اور حقیقی ڈیوائس پر test کرنا ہوگا۔ صرف build کامیاب ہونا ان فیچرز کے کام کرنے کا ثبوت نہیں ہے۔

## GitHub سے APK بنانا (موبائل پر)
1. اس ZIP کو GitHub repository میں upload کریں اور default branch کا نام `main` رکھیں۔
2. Actions tab کھولیں۔ `Build Noor3D Android APK` workflow منتخب کریں۔
3. `Run workflow` دبائیں۔
4. مکمل ہونے کے بعد workflow run کے `Artifacts` حصے سے `Noor3D-debug-apk` ڈاؤن لوڈ کریں۔

## Build environment
- JDK 17
- Android Gradle Plugin 8.6.1
- Kotlin 2.0.20
- compileSdk 35 / minSdk 26
